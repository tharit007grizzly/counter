import React, { Component } from 'react';
import Header from './header'
import Footer from './Footer'

class App extends Component {
  render() {
    return (
        <div>
          <Header currentUser = "Tharit" loginUser />
          <Footer></Footer>
        </div>

    );
  }
}

export default App;
